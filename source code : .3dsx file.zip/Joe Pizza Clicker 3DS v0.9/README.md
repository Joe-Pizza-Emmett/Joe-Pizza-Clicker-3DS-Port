# 3dsCookieClicker
Cookie Clicker for 3ds
That is a port of Browser game called "Cookie Clicker" for 3ds
made on Lua
it's my first lua game
